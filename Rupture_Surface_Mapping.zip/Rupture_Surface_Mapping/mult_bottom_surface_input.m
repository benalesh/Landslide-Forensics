clear all;

%{
F:\Strength_Manuscript\Substudies\Elk_City_Study
F:\Strength_Manuscript\Substudies\Ophir
F:\Strength_Manuscript\Substudies\Port_Orford


F:\Strength_Manuscript\Substudies\Box_Slide_Study
F:\Strength_Manuscript\Substudies\AZI_Study

F:\Strength_Manuscript\Substudies\AZI_phi15
F:\Strength_Manuscript\Substudies\AZI_phi45
F:\Strength_Manuscript\Substudies\Box_phi45
F:\Strength_Manuscript\Substudies\Box_phi20
%}


%% RUN
path = 'C:\Current Projects\SPR808\Forensics\US20_Forensics'
path2 = path;
extent = 'OUTSIDE'

phi2 = 25;
entry = 0.26;
lambda = 0.83;

mult_bottom_surface_function(path,path2,extent,phi2,entry,lambda)
path =[]; path2 = []; extent = [];

% %% RUN
% path = 'F:\Strength_Manuscript\Substudies\Ophir'
% path2 = path;
% extent = 'OUTSIDE'
% 
% phi2 = 35;
% entry = 0.26;
% lambda = 0.83;
% 
% mult_bottom_surface_function(path,path2,extent,phi2,entry,lambda)
% path =[]; path2 = []; extent = [];
% 
% %% RUN
% path = 'F:\Strength_Manuscript\Substudies\Elk_City_Study'
% path2 = path;
% extent = 'OUTSIDE'
% 
% phi2 = 25;
% entry = 0.26;
% lambda = 0.83;
% 
% mult_bottom_surface_function(path,path2,extent,phi2,entry,lambda)
% path =[]; path2 = []; extent = [];
