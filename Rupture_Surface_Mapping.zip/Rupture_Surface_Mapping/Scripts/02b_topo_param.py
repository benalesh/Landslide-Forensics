##########################################################################
# 02b_topo_param.py
# or "02b Compute Topographic Parameters" tool in the Landslide_Expression toolbox
#
# By Michael Bunn, Ben Leshchinsky, and Michael Olsen
# Oregon State University
# Last Updated: 01/22/2019
#
# Creation of this tool has been supported by the Norman & Evelyn Wildish
# Graduate Fellowship at Oregon State University
#
# Direct questions to ben.leshchinsky@oregonstate.edu
##########################################################################

# Import proper modules
import arcpy, os
arcpy.env.overwriteOutput=True
from arcpy.sa import *

# Read inputs: Slope, Aspect, Outline Polygon (OUTSIDE.shp)
# Ask user for file inputs
proj_loc = arcpy.GetParameterAsText(0)# Project folder
georef = arcpy.GetParameterAsText(1);# Coordinate System

# Set project folder as workspace
arcpy.env.workspace = proj_loc

# Select necessary files from workspace
DEM = "Proj_DEM.tif"
Ext = "OUTSIDE.shp"

# Create the following files
aspect = "aspect.tif"
slope = "slope.tif"

# Compute slope and aspect rasters
outSlope = Slope(DEM)
outSlope.save(slope)

outAspect = Aspect(DEM)
outAspect.save(aspect)

# Compute zonal statistics














# Check in license (as needed)