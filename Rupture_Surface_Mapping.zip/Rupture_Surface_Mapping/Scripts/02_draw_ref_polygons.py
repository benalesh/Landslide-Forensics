##########################################################################
# 02_draw_ref_polygons.py
# or "02 Draw Refined Polygons" tool in the Landslide_Expression toolbox
#
# By Michael Bunn, Ben Leshchinsky, and Michael Olsen
# Oregon State University
# Last Updated: 10/25/2018
#
# Creation of this tool has been supported by the Norman & Evelyn Wildish
# Graduate Fellowship at Oregon State University
#
# Direct questions to ben.leshchinsky@oregonstate.edu
##########################################################################

# Import proper modules
import arcpy, os
arcpy.env.overwriteOutput=True
from arcpy.sa import *

# Set the outputMFlag environment to Disabled
arcpy.env.outputMFlag = "Disabled"

# Set the outputZFlag environment to Disabled
arcpy.env.outputZFlag = "Disabled"

# Ask user for file inputs
proj_loc = arcpy.GetParameterAsText(0)# Project folder
georef = arcpy.GetParameterAsText(1);# Coordinate System

# Set project folder as workspace
arcpy.env.workspace = proj_loc

# Specify raster names
bottom = "BOTTOM_BUNN.tif"
top = "TOP_BUNN.tif"

# bottom_temp = "bottom_temp.tif"
# top_temp = "top_temp.tif"

bottom_shp = "INSIDE.shp"
top_shp = "OUTSIDE.shp"

# Define projections
arcpy.DefineProjection_management(bottom,georef)
arcpy.DefineProjection_management(top,georef)

# # Convert 0 values to NoData
# btemp = Con(Raster(bottom) != 0,Raster(bottom))
# ttemp = Con(Raster(top) != 0,Raster(top))
# btemp.save(bottom_temp)
# ttemp.save(top_temp)

# Create polygons from rasters
arcpy.RasterToPolygon_conversion(bottom,bottom_shp)
arcpy.RasterToPolygon_conversion(top,top_shp)

arcpy.MakeFeatureLayer_management(bottom_shp,"blyr")
arcpy.SelectLayerByAttribute_management("blyr", "NEW_SELECTION", "gridcode = 0")
arcpy.DeleteFeatures_management("blyr")
arcpy.Delete_management("blyr")

arcpy.MakeFeatureLayer_management(top_shp,"tlyr")
arcpy.SelectLayerByAttribute_management("tlyr", "NEW_SELECTION", "gridcode = 0")
arcpy.DeleteFeatures_management("tlyr")
arcpy.Delete_management("tlyr")

