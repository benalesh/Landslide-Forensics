##########################################################################
# 03_comp_depth.py
# or "03 Define Projections and Compute Depth" tool in the Landslide_Expression toolbox
#
# By Michael Bunn, Ben Leshchinsky, and Michael Olsen
# Oregon State University
# Last Updated: 12/05/2018
#
# Creation of this tool has been supported by the Norman & Evelyn Wildish
# Graduate Fellowship at Oregon State University
#
# Direct questions to ben.leshchinsky@oregonstate.edu
##########################################################################

# Import proper modules
import arcpy, os
arcpy.env.overwriteOutput=True
from arcpy.sa import *

# Set the outputMFlag environment to Disabled
arcpy.env.outputMFlag = "Disabled"

# Set the outputZFlag environment to Disabled
arcpy.env.outputZFlag = "Disabled"

# Ask user for file inputs
proj_loc = arcpy.GetParameterAsText(0)# Project folder
georef = arcpy.GetParameterAsText(1);# Coordinate System

# Set project folder as workspace
arcpy.env.workspace = proj_loc

# Specify raster names
bottom = "slip_surf.tif"
top = "ground_surf.tif"

# Define projections
arcpy.DefineProjection_management(bottom,georef)
arcpy.DefineProjection_management(top,georef)

# Compute difference raster
outMinus = Minus(top,bottom)
outMinus.save("diff_surf.tif")

