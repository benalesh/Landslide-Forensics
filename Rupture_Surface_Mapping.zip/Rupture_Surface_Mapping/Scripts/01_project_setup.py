##########################################################################
# 01_project_setup.py
# or "01 Project Setup" tool in the Landslide_Expression toolbox
#
# By Michael Bunn, Ben Leshchinsky, and Michael Olsen
# Oregon State University
# Last Updated: 10/25/2018
#
# Creation of this tool has been supported by the Norman & Evelyn Wildish
# Graduate Fellowship at Oregon State University
#
# Direct questions to ben.leshchinsky@oregonstate.edu
##########################################################################

# Import proper modules
import arcpy, os
arcpy.env.overwriteOutput=True
arcpy.CheckOutExtension("3D")
from arcpy.sa import *

# Set the outputMFlag environment to Disabled
arcpy.env.outputMFlag = "Disabled"

# Set the outputZFlag environment to Disabled
arcpy.env.outputZFlag = "Disabled"

# Ask user for file locations
proj_loc = arcpy.GetParameterAsText(0)# Location to save project folder
proj_name = arcpy.GetParameterAsText(1)# Project Name
DEM = arcpy.GetParameterAsText(2)# DEM
deps = arcpy.GetParameterAsText(3)# Deposits
fnks = arcpy.GetParameterAsText(4)# Scarp Flanks

# Create new folder
directory = proj_loc+"\\"+proj_name
if not os.path.exists(directory):
	os.makedirs(directory)

# Set new folder as workspace
arcpy.env.workspace = directory

# Get units from DEM and display for the world to see!
spat = arcpy.Describe(DEM).spatialReference
unit = spat.linearUnitName

commentval = "DEM units are: "+unit
arcpy.AddMessage(commentval)

# Copy DEM to new folder	
ProjDEM = "ProjDEM.tif"
arcpy.CopyRaster_management(DEM,ProjDEM)

# Create the following files
aspect = "aspect.tif"
slope = "slope.tif"

# Compute slope and aspect rasters
outSlope = Slope(ProjDEM)
outSlope.save(slope)

outAspect = Aspect(ProjDEM)
outAspect.save(aspect)

# Name outputs
D = "ProjDEP.shp"
F = "ProjFLK.shp"
domain_temp = "domain.shp"

# Perform raster domain to get extents of DEM.
arcpy.RasterDomain_3d(ProjDEM,domain_temp,"POLYGON")

# Use extents to clip flanks and deposits
arcpy.Clip_analysis(deps,domain_temp,D)
arcpy.Clip_analysis(fnks,domain_temp,F)

arcpy.MakeFeatureLayer_management(D,"D")
arcpy.SelectLayerByLocation_management("D", "BOUNDARY_TOUCHES", domain_temp, "", "NEW_SELECTION")
arcpy.DeleteFeatures_management("D")
arcpy.Delete_management("D")

arcpy.MakeFeatureLayer_management(F,"F")
arcpy.SelectLayerByLocation_management("F", "BOUNDARY_TOUCHES", domain_temp, "", "NEW_SELECTION")
arcpy.DeleteFeatures_management("F")
arcpy.Delete_management("F")

# Delete variables
arcpy.Delete_management(domain_temp)

arcpy.CheckInExtension("3D")