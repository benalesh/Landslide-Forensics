clear all;

DEM = 'F:\Strength_Manuscript\Substudies\Elk_City_Study\ProjDEM.tif';
dep_shp ='F:\Strength_Manuscript\Substudies\Elk_City_Study\Rupture_Surfaces\Catastrophic.shp';
lambda = 0.1;
mult_top_surface_function(DEM,dep_shp,lambda);


