% clear all

% Read files

% path = uigetdir('F:\Strength_Manuscript\Substudies','Project to Map')
% path2 = uigetdir('F:\Strength_Manuscript\Substudies','Project of Parameters')
% extent = questdlg('Use INSIDE or OUTSIDE extents?','Landslide Extents','INSIDE','OUTSIDE','Cancel');
function mult_bottom_surface_function(path,path2,extent,phi2,entry,lambda)
warning off
tic;
[~,study] = fileparts(path2);
dep_shp = fullfile(path,[extent,'2.shp']);
DEM = fullfile(path,'ProjDEM.tif');
ASP = fullfile(path,'aspect.tif');
SLP = fullfile(path,'slope.tif');

% % Read Settings
% M = csvread(fullfile(path2,'settings.csv'),1,0);
% phi2 = M(1);
% M = [];
% 
% M = csvread(fullfile(path2,[extent,'_best_values.csv']),1,1);
% entry = M(1);
% lambda = M(3);
% M = [];

% Create directory to store results
pathB = fullfile(path,'Rupture_Surfaces');
pathC = fullfile(pathB,'cross_sections');
if exist(pathB) == 7
    fprintf('Run Folder Already Exists\n')
    if exist (pathC) == 7
        fprintf('Cross Section Folder Already Exists\n')
    else
        mkdir(pathC);
    end
else
    mkdir(pathB);
    mkdir(pathC);
end

% Read files
PASSIVE = csvread('T:\Strength_Manuscript\Mohrs_Circle\pa.csv',1,0);
ACTIVE = csvread('T:\Strength_Manuscript\Mohrs_Circle\active.csv',1,0);

shear = fullfile(pathB,'slip_surf.tif');
top = fullfile(pathB,'top_surf.tif');
attr = fullfile(pathB,'attributes.shp');

geoinfo = geotiffinfo(DEM);
dep_F = shaperead(dep_shp);

csize = geoinfo.PixelScale(1);

[A,R] = geotiffread(DEM);
[SLOPE] = geotiffread(SLP);
[ASPECT] = geotiffread(ASP);

[M,N] = size(A);
[x,y] = pixcenters(geoinfo);

% Convert x-y arrays to grid
[X,Y] = meshgrid(x,y);
Xv = reshape(X,[],1);
Yv = reshape(Y,[],1);
x = []; y = [];
A(isnan(A)) = 0;
A(A<0) = 0;
A0 = A;

for idx = 1:length(dep_F)
    tst = toc;
    % Display landslide number
    print_text = ['Working on slide ',num2str(idx),' of ',num2str(length(dep_F)),'\n'];
    fprintf(print_text)
    x = []; y = []; z = [];
    % Get xyz from shapefile
    x = dep_F(idx).X(1:end-1);
    y = dep_F(idx).Y(1:end-1);
    z = interp2(X,Y,A0,x,y);
    
    fail_type = dep_F(idx).FAIL_TYPE;
    % Make mask
    mask = create_shp_mask(dep_F,idx,geoinfo);    
    
    % Compute aspect (mind to 360 to 0 jump) and slope (aspect starts in
    % north direction and rotates clockwise)
    temp_asp = ASPECT(mask);
    mean_asp180 = mean(temp_asp(temp_asp>180));
    cnt_asp180 = sum(temp_asp(temp_asp>180));
    mean_asp0 = mean(temp_asp(temp_asp<=180));
    cnt_asp0 = sum(temp_asp(temp_asp<=180));
    if cnt_asp180 == 0
        mean_asp180 = 0;
    end
    if cnt_asp0 == 0
        mean_asp0 = 0;
    end
    if mean_asp180 > (mean_asp0+180)
        aspect = ((mean_asp180-360)*cnt_asp180+mean_asp0*cnt_asp0)/(cnt_asp180+cnt_asp0);
    else
        aspect = (mean_asp180*cnt_asp180+mean_asp0*cnt_asp0)/(cnt_asp180+cnt_asp0);
    end
    slope_degrees = mean(SLOPE(mask));
    
    % Get center point of landslide extent
    xcent = mean(X(mask));
    ycent = mean(Y(mask));
    
    % Compute orientation to vertices from center (starts in east direction
    % and positive rotation is counter clockwise)
    orient = atan2d((y-ycent),(x-xcent));
    
    % Convert aspect angles to the same coordinate system as 'orient'
    corr_asp = 270-aspect;
    norm_or = orient-corr_asp;
    
    
    % Compute the dive slope (adapted from Terzaghi 1943)
    beta = round(slope_degrees);
    if beta>45
        beta = 45;
    end
    pang = PASSIVE(phi2,beta);
    aang = ACTIVE(phi2,beta);
    v = cosd(norm_or);
    slp = zeros(size(v));
    slp(v>0) = abs(v(v>0).*(beta+aang));
    slp(v<=0) = abs(-v(v<=0).*(beta-pang));
    
    % Compute interpolation points
    radial = sqrt((y-ycent).^2+(x-xcent).^2);
    radial2 = radial.*(1+entry);
    radial3 = radial.*(1-entry);
    
    dr = radial2-radial;
    dz = tand(slp).*dr;
    
    dr2 = radial-radial3;
    dz2 = tand(slp).*dr2;
    
    x2 = radial2.*cosd(orient)+xcent;
    y2 = radial2.*sind(orient)+ycent;
    z2 = z+dz;
    
    x3 = radial3.*cosd(orient)+xcent;
    y3 = radial3.*sind(orient)+ycent;
    z3 = z-dz2;
    
    xin = [x,x2,x3]';
    yin = [y,y2,y3]';
    zin = [z,z2,z3]';

    npts = 1;
    [a,w,xfit,yfit,zfit] = fit_tps(xin,yin,zin,npts,lambda);
    [a2,w2,xfit2,yfit2,zfit2] = fit_tps(x,y,z,npts,lambda);
    
    % Apply spline to mask points
    
    mask_buff = mask;
    for i= 1:1
        mask_buff = imdilate(mask_buff,[1 1 1; 1 1 1; 1 1 1]);
    end
    mask_buff = mask_buff>0;
    
    xm = Xv;
    ym = Yv;
    
    zm = calc_tps(xm,ym,a,w,xfit,yfit);
    zm2 = calc_tps(xm,ym,a2,w2,xfit2,yfit2);
    
    zout = reshape(zm,M,N);
    zout2 = reshape(zm2,M,N);

    B = A0;
    C = A0;
    
    B(zout<A0)= zout(zout<A0);
    B(~mask_buff) = A0(~mask_buff);
    
    C(zout<A0) = zout2(zout<A0);
    C(~mask_buff) = A0(~mask_buff);
    
    if strcmp(fail_type,'Catastrophic') ==1
        D = C-B;
    else
        D = A-B;
    end
    A0 = B;
    
    ruplen = getCX(norm_or,X,Y,A,B,C,pathB,x,y,z,dep_F(idx).Id);
    
    tend = toc;
    ctime = tend-tst;
    % Write attributes to shapefile
    ncells = sum(sum(mask));
    dep_F(idx).ncells = ncells;
    dep_F(idx).area_ft2 = csize*csize*ncells;
    dep_F(idx).volume_ft3 = double(sum(sum(csize*csize*D(mask))));
    dep_F(idx).max_depth = double(max(D(mask)));
    dep_F(idx).avg_depth = double(mean(D(mask)));
    dep_F(idx).time = double(ctime);
    dep_F(idx).aspect = double(aspect);
    dep_F(idx).slope = double(slope_degrees);
    dep_F(idx).npts = double(length(x));
    dep_F(idx).lslip = double(ruplen);
    
end

geotiffwrite(shear,B,R,'CoordRefSysCode',26912)
geotiffwrite(top,C,R,'CoordRefSysCode',26912)
shapewrite(dep_F,attr)
try

study = {study};
T = table(study,entry,lambda,phi2,csize);
runfile = fullfile(pathB,'run_info.csv');
writetable(T,runfile)
catch
end
end

function ruplen = getCX(norm_or,X,Y,A,B,C,pathB,x,y,z,idx)    
	% Get point closest to 0 or 180 (even numbers are closer to 360, odd numbers are closer to 180)
	blk = zeros(size(norm_or));
	% eoo: 0 is even, 1 is odd
	eoo = mod(round(abs(norm_or)/180),2);
	orr = mod(abs(norm_or),180);
	orr(orr>90) = 180-orr(orr>90);
    evenv = blk(eoo==0);
    oddv = blk(eoo==1);
	[~,id0] = min(orr(eoo==0));% even is 0|360 degrees
	[~,id180] = min(orr(eoo==1));% odd is 180 degrees
    evenv(id0) = 1;
    oddv(id180) = 1;
    blk(eoo==0) = evenv;
    blk(eoo==1) = oddv;
    ifung = blk>0.5;
    xcx = x(ifung)';
    ycx = y(ifung)';
    [~,maxpt] = max(z(ifung));
    [~,minpt] = min(z(ifung));
    xf = xcx(maxpt);yf = ycx(maxpt);
    x0 = xcx(minpt);y0 = ycx(minpt);
    
	
    xlen = sqrt((yf-y0)^2+(xf-x0)^2);
    x_dist = 1:20:round(xlen);
    
    dlen = x_dist./xlen;
    xsamp = dlen*(xf-x0)+x0;
    ysamp = dlen*(yf-y0)+y0;
    Aq = interp2(X,Y,A,xsamp,ysamp);
    Bq = interp2(X,Y,B,xsamp,ysamp);
    Cq = interp2(X,Y,C,xsamp,ysamp);

    
    horiz = x_dist';
    x_coord = xsamp';
    y_coord = ysamp';
    ground = Aq';
    slip = Bq';
    top_int = Cq';
    
    pathC = fullfile(pathB,'cross_sections');
    xsectfile = fullfile(pathC,['xsection',num2str(idx),'.csv']);
    TX = table(x_coord,y_coord,horiz,ground,slip,top_int);
    writetable(TX,xsectfile)
    
    seglen(1) = 0;
    for i = 2:length(x_dist)
        dz = Bq(i)-Bq(i-1);
        dx = x_dist(i)-x_dist(i-1);
        seglen(i) = sqrt(dz^2+dx^2);
    end
    ruplen = sum(seglen);
end

function [a,w,x_fit,y_fit,z_fit] = fit_tps(x,y,z,npts,lambda)
    %% Fit TPS to selection of mask ring points
	p0 = length(x);
    intp = [npts:npts:length(x)];
    x = x(intp);
    y = y(intp);
    z = z(intp);
	
	% Compute the distances between bpoints
	p = length(x);
	r = zeros(p,p);
	for i = 1:p
		for j = 1:p
            r(i,j) = sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
        end
	end
	
	% Prepare matrices to solve for w and a
    try
        P = [ones(p,1),x,y];
    catch
        x = x';
        y = y';
        P = [ones(p,1),x,y];
    end
	O = zeros(3);
	K = (r.^2).*log(r);
	iK = isnan(K);
	K(iK) = 0;
	sumr = sum(sum(r));
	alpha = sumr/p^2;
	I = eye(size(K));
	K = I.*lambda*alpha^2+K;
	
	% regularize (Code is present but not active)
% 	lambda = 0.1;
	I = eye(size(K));
	K = I.*lambda+K;
	
	% Solve for w and a
	MAT = [K,P;P',O];
    try
        b = [z;[0;0;0]];
    catch
        z = z';
        b = [z;[0;0;0]];
    end
    R = MAT\b;
	
	w = R(1:p);
	a = R(p+1:end);
	
	x_fit = x;
	y_fit = y;
    z_fit = z;
end

function z = calc_tps(x,y,a,w,X,Y)
    %% Apply TPS defined by w to the mask pixels
	d0 = zeros(length(X),1);
	for i = 1:length(x)
		for j = 1:length(X)
			d0(j,1) = sqrt((X(j)-x(i))^2+(Y(j)-y(i))^2);
		end
		
        rside = sum((d0.^2).*log(d0).*w);
		lside = a(1)+a(2)*x(i)+a(3)*y(i);
		
		z(i) = rside+lside;
		
	end
end

function mask = create_shp_mask(shapefile,feat_num,geotiffinfo)
    %% Create binary mask from input polygons
	% Get x-y locations of pixels
	[x,y] = pixcenters(geotiffinfo);
	
	% Convert x-y arrays to grid
	[X,Y] = meshgrid(x,y);
	
	% Select single polygon and remove training NaN
	rx = shapefile(feat_num).X(1:end-1);
	ry = shapefile(feat_num).Y(1:end-1);
	
	mask = inpolygon(X,Y,rx,ry);
end
