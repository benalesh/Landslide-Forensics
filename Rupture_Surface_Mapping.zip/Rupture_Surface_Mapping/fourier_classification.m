clear all;
close all;
%% Load DEM and shapefile, gather other necessary info
% path = 'F:\Strength_Manuscript\Substudies\HemlockElk_Study';
% path = 'F:\Strength_Manuscript\Substudies\Port_Orford';
% path = 'F:\Strength_Manuscript\Substudies\Swan_Studies\Swan_02'
path = uigetdir('F:\Strength_Manuscript\Substudies\Manuscript_3')
FLANKS = fullfile(path,'ProjFLK');
DEPOSITS = fullfile(path,'ProjDEP.shp');
DEM = fullfile(path,'ProjDEM.tif');

F = shaperead(FLANKS);
O = [];
D = shaperead(DEPOSITS);
geoinfo = geotiffinfo(DEM);
[A,R] = geotiffread(DEM);

% Get units
unit_str = geoinfo.UOMLength;

rmse_cut = 10;

EMAT = zeros(size(A));
DMAT = zeros(size(A));


for i = 1:length(D)
    Duid{i} = D(i).UNIQUE_ID;
end

% Create x-y grid corresponding to DEM
[x,y] = pixcenters(geoinfo);
[X,Y] = meshgrid(x,y);
clearvars x y

cnt = 1;
for idx = 1:length(F)
% for idx = 320:1:350
    % Make sure that deposits and flanks have same UNIQUE_ID
    Fuid = F(idx).UNIQUE_ID;
    uid = strcmp(Fuid,Duid);
    fail_type = [];
    
    % If deposits and flanks match, then begin working
    if sum(uid) ==1
        print_text = ['Working on slide ',num2str(idx),' of ',num2str(length(F)),'\n'];
        fprintf(print_text)

        % Remove points from interior of scarp flank - they won't be used for
        % fitting
        dep = find(uid==1);

        xf = F(idx).X(1:end-1);
        yf = F(idx).Y(1:end-1);

        xd = D(dep).X(1:end-1);
        yd = D(dep).Y(1:end-1);
        [x0,y0,full_poly] = obtain_edges(xf,yf,xd,yd);
    
        y0(isnan(x0)) = [];
        x0(isnan(x0)) = [];
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        
        % Subtract average value to reduce number of digits and improve
        % computational efficiency
        xnorm = x0-mean(x0);
        ynorm = y0-mean(y0);

        % Compute coordinates of central point that is a consistent distance
        % from all flank points
%         try%****************SHOULD NOT BE NECESSARY************************
        [xcent,ycent] = find_centroid(xnorm,ynorm);
        xcent0 = xcent+mean(x0);% convert center back to projected coords
        ycent0 = ycent+mean(y0);

        % Center flank point coordinates around the central point
        xpol = x0-xcent0;
        ypol = y0-ycent0;
        
        xdpol = xd-xcent0;
        xfpol = xf-xcent0;
        ydpol = yd-ycent0;
        yfpol = yf-ycent0;

        % Fit Fourier series to flank points
        nterms = 2;
        [xfit,yfit,a,xcomp,ycomp,rhoRMSE(idx,1)] = fourier_fit(xpol,ypol,nterms);
        [~,pre_rmean] = self_distance_distr(xpol,ypol);
        [~,fit_rmean] = self_distance_distr(xcomp,ycomp);
        

        [fail_type,type2(idx,1)] = determine_fail_type(fit_rmean,rmse_cut,rhoRMSE(idx,1));
%         fail_type = 'Progressive';%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%<<<<<<<<FDFDFDSFS
%         catch%***************SHOULD NOT BE NECESSARY***********************
%             fail_type = 'Progressive';
%             type2(idx,1) = 0;
%         end%****************SHOULD NOT BE NECESSARY************************
        
        % Get combined polygons
        xfit = xfit+xcent0;
        yfit = yfit+ycent0;
        
        polyfit = polyshape(xfit,yfit);
        polyin = [full_poly polyfit];
        clip_poly = intersect(polyin);
        
        if strcmp(fail_type,'Catastrophic')==1
            outside = clip_poly;
        else
            outside = full_poly;
        end
        
        O(cnt).Geometry = 'Polygon';
        O(cnt).BoundingBox = [min(outside.Vertices(:,1)),...
            min(outside.Vertices(:,2)),...
            max(outside.Vertices(:,1)),...
            max(outside.Vertices(:,2))];
        xt = outside.Vertices(:,1);
        yt = outside.Vertices(:,2);

        O(cnt).X = [xt;NaN];
        O(cnt).Y = [yt;NaN];
        O(cnt).UNIQUE_ID = F(idx).UNIQUE_ID;
        O(cnt).FAIL_TYPE = fail_type;
        O(cnt).RMSE = rhoRMSE(idx,1);
        O(cnt).Id = idx;
        cnt = cnt+1;
        
        
        
            
        
        [emask,dmask] = get_extent(xf,yf,xd,yd,xfit,yfit,xcent0,ycent0,X,Y,fail_type);
        EMAT(emask==1) = idx;
        DMAT(dmask==1) = idx;

        EMAT = uint32(EMAT);
        DMAT = uint32(DMAT);

        emask = [];
        dmask = [];

    end
    % Do nothing if UNIQUE_IDs do not match
    
    idxlist(idx,1) = idx;
    if isempty(fail_type)
        fail_type = 'Unassigned';
        type2(idx,1) = 0;
    end
    faillist{idx,1} = fail_type;
    fail_type = [];
    F(idx).fail_type = {fail_type};
    unid{idx,1} = F(idx).UNIQUE_ID;
end

outside_file = fullfile(path,'OUTSIDE2.shp');
shapewrite(O,outside_file);
T = table(idxlist,faillist,unid,rhoRMSE,type2);
T_file = fullfile(path,['fail_type.txt']);
writetable(T,T_file)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function [x,y,polyout] = obtain_edges(xf,yf,xd,yd)
    %% Remove coordinates from scarp flank that correspond to deposits
    % Leaves only coordinates on the outside edge
    r = zeros(length(xf),length(xd));
    for i = 1:length(xf)
        for j = 1:length(xd)
            r(i,j) = sqrt((xf(i)-xd(j))^2+(yf(i)-yd(j))^2);
        end
    end
    
    no_r = r<5;
    [fi,di] = find(r<3);
    xd(di) = xf(fi);
    yd(di) = yf(fi);
    rem = sum(no_r,2);
    rem = rem>0.5;
    remd = sum(no_r,1);
    remd = remd>0.5;
    clearvars r no_r;
    
    
    polyf = polyshape(xf,yf);
    polyd = polyshape(xd,yd);
    polyin = [polyf polyd];
    polyout = union(polyin);
    
    x = xf(~rem);
    y = yf(~rem);
end

%%
function [xcent,ycent] = find_centroid(xnorm,ynorm)
    %% Find the point in space whose distances to all flank nodes are most
    % similar
    
    try
        % Evaluate the distance between points - find min and max distance
        r = zeros(length(xnorm),length(ynorm));
        for i= 1:length(xnorm)
            for j = 1:length(ynorm)
                r(i,j) = sqrt((xnorm(i)-xnorm(j))^2+(ynorm(i)-ynorm(j))^2);
            end
        end
        r_vec = reshape(r,[],1);
        r0 = r_vec==0;
        r_vec(r0) = [];

        % Use the minimum and maximum distances to establish a sample grid
        min_r = min(r_vec);
        max_r = max(r_vec);
    %     xgrid = [min(xnorm)-max_r:min_r:max(xnorm)+max_r];
    %     ygrid = [min(ynorm)-max_r:min_r:max(ynorm)+max_r];
        xgrid = [min(xnorm):min_r:max(xnorm)];
        ygrid = [min(ynorm):min_r:max(ynorm)];
        [X,Y] = meshgrid(xgrid,ygrid);

        % Evaluate the distance between each grid point and all flank points
        inc = 1;
        minsize = min([size(X,1) size(X,2)]);

        if minsize > 100
            inc = round((minsize/100));
        end
        for i = 1:inc:size(X,1)
            for j = 1:inc:size(X,2)
                for k = 1:length(xnorm)
                    rgrid(k,1) = sqrt((X(i,j)-xnorm(k))^2+(Y(i,j)-ynorm(k))^2);
                end
                stdgrid(i,j) = std(rgrid);
                avggrid(i,j) = mean(rgrid);
            end
        end
        min1 = min(stdgrid,[],1);
        min2 = min(stdgrid,[],2);

        [minstd,gridcol] = min(min1);
        [~,gridrow] = min(min2);


        xcent = X(gridrow,gridcol);
        ycent = Y(gridrow,gridcol);
    catch
        xcent = mean(xnorm);
        ycent = mean(ynorm);
        fprintf('\nVery Big Slide')
    end
end

function [xfit,yfit,a,xcomp,ycomp,rhoRMSE] = fourier_fit(xpol,ypol,nterms)
    warning off
    %% Fit fourier series to the flank points
    % Convert cartesian coordinates to polar 
    rho = sqrt(xpol.^2+ypol.^2);
    rho0 = rho;
    theta = atan2(ypol,xpol);
    theta0 = theta;
    theta(theta<0) = theta(theta<0)+2*pi;
    
    % Define Fourier function to use in fitting
    if nterms == 1
        fourier_fun = @(a,theta) a(1)/2 + a(2)*cos(1*theta) + a(3)*sin(1*theta);
        a0 = zeros(3,1)+mean(rho);
    elseif nterms == 2
        fourier_fun = @(a,theta) a(1)/2 + a(2)*cos(1*theta) + a(3)*sin(1*theta)...
            + a(4)*cos(2*theta) + a(5)*sin(2*theta);
        a0 = zeros(5,1)+mean(rho);
    elseif nterms == 2
        fourier_fun = @(a,theta) a(1)/2 + a(2)*cos(1*theta) + a(3)*sin(1*theta)...
            + a(4)*cos(2*theta) + a(5)*sin(2*theta)...
            + a(6)*cos(3*theta) + a(7)*sin(3*theta);
        a0 = zeros(7,1)+mean(rho);
    elseif nterms == 2  
        fourier_fun = @(a,theta) a(1)/2 + a(2)*cos(1*theta) + a(3)*sin(1*theta)...
            + a(4)*cos(2*theta) + a(5)*sin(2*theta)...
            + a(6)*cos(3*theta) + a(7)*sin(3*theta)...
            + a(8)*cos(4*theta) + a(9)*sin(4*theta);
        a0 = zeros(9,1)+mean(rho);
    else 
        fourier_fun = @(a,theta) a(1)/2 + a(2)*cos(1*theta) + a(3)*sin(1*theta)...
            + a(4)*cos(2*theta) + a(5)*sin(2*theta)...
            + a(6)*cos(3*theta) + a(7)*sin(3*theta)...
            + a(8)*cos(4*theta) + a(9)*sin(4*theta)...
            + a(10)*cos(4*theta) + a(11)*sin(4*theta);
        a0 = zeros(11,1)+mean(rho);
    end
    
    % Interpolate the flank points to regular increments to avoid weird
    % behavior from conflicting nearby points
    theta(1) = [];
    rho(1) = [];
    
    [theta, tidx] = unique(theta);
    theta_fit = [min(theta)+0.1:pi/8:max(theta)-0.1];
    rho_fit = interp1(theta,rho(tidx),theta_fit);
    
    a = lsqcurvefit(fourier_fun,a0,theta_fit,rho_fit);
    rho_comp = fourier_fun(a,theta0);
    
    rhoRMSE = sqrt(sum((rho_comp-rho0).^2)/length(rho));
    
    theta_apply = 0:pi/25:2*pi;
    rho_apply = fourier_fun(a,theta_apply);

    
    xfit = rho_apply.*cos(theta_apply);
    yfit = rho_apply.*sin(theta_apply);
    
    xcomp = rho_comp.*cos(theta0);
    ycomp = rho_comp.*cos(theta0);
    
end

function [fail_type,type2] = determine_fail_type(fit_rmean,RMSE_thresh,rhoRMSE)
    %% Determine if landslides are progressive or catastrophic
    % First criteria - are internal distances between nodes similar to the
    % scarp flank? For catastrophic, the answer is yes.
    
    % Second criteria - shapes must be closed (pks>1) and not
    % self-intersect (pks>2)
    pks = findpeaks(fit_rmean);
    
    % Evaluate criteria and assign type
    if length(pks) == 2 && rhoRMSE<RMSE_thresh
        fail_type = 'Catastrophic';
        type2 = 1;
    else
        fail_type = 'Progressive';
        type2 = 0;
    end
end


function [rdist,rmean] = self_distance_distr(x,y)
    %% Get internal distances for each polygon
    rdist = zeros(length(x),length(y));
    for i = 1:length(x)
        for j = 1:length(y)
            rdist(i,j) = sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
        end
    end
    rmean = mean(rdist,1);
    rdist = tril(rdist);
    rdist = reshape(rdist,[],1);
    rdist(rdist==0) = [];
end


function [emask,dmask] = get_extent(xf,yf,xd,yd,xfit,yfit,xcent0,ycent0,X,Y,fail_type)

    % Create mask from each polygon
    dmask = inpolygon(X,Y,xd,yd);
    fmask = inpolygon(X,Y,xf,yf);
    mask = inpolygon(X,Y,xfit,yfit);
    emask = (fmask+dmask)>0.5;
    
    % Consider the catastrophic scenario
    if strcmp(fail_type,'Catastrophic')==1
        emask = emask.*mask;
        dmask = dmask.*mask;
    end

end


