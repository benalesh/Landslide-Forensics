% clear all

% Read files

% path = uigetdir('F:\Strength_Manuscript\Substudies','Project to Map')
% path2 = uigetdir('F:\Strength_Manuscript\Substudies','Project of Parameters')
% extent = questdlg('Use INSIDE or OUTSIDE extents?','Landslide Extents','INSIDE','OUTSIDE','Cancel');
function mult_top_surface_function(DEM,dep_shp,lambda)
warning off

% DEM = 'F:\Strength_Manuscript\Substudies\AZI_40\ProjDEM.tif';
% dep_shp ='F:\Strength_Manuscript\Substudies\AZI_40\AZI_40_OUTSIDE_parameters\attributes.shp';

% lambda = 0.1;


% Create directory to store results
[pathB,~,~] = fileparts(dep_shp)
if exist(pathB) == 7
    fprintf('Run Folder Already Exists\n')
else
    mkdir(pathB);
end

top = fullfile(pathB,'top_surf2.tif');


geoinfo = geotiffinfo(DEM);
dep_F = shaperead(dep_shp);

csize = geoinfo.PixelScale(1);

[A,R] = geotiffread(DEM);

[M,N] = size(A);
[x,y] = pixcenters(geoinfo);

% Convert x-y arrays to grid
[X,Y] = meshgrid(x,y);
Xv = reshape(X,[],1);
Yv = reshape(Y,[],1);
x = []; y = [];
A(isnan(A)) = 0;
A(A<0) = 0;
A0 = A;

for idx = 1:length(dep_F)

    % Display landslide number
    print_text = ['Working on slide ',num2str(idx),' of ',num2str(length(dep_F)),'\n'];
    fprintf(print_text)
    x = []; y = []; z = [];
    % Get xyz from shapefile
    x = dep_F(idx).X(1:end-1);
    y = dep_F(idx).Y(1:end-1);
    z = interp2(X,Y,A0,x,y);
    
    mask = create_shp_mask(dep_F,idx,geoinfo);    
    
    xin = x';
    yin = y';
    zin = z';

    npts = 1;
    [a,w,xfit,yfit,zfit] = fit_tps(xin,yin,zin,npts,lambda);
    
    % Apply spline to mask points
    
    mask_buff = mask;
    for i= 1:1
        mask_buff = imdilate(mask_buff,[1 1 1; 1 1 1; 1 1 1]);
    end
    mask_buff = mask_buff>0;
    
    xm = Xv;
    ym = Yv;
    
    zm = calc_tps(xm,ym,a,w,xfit,yfit);
    
    zout = reshape(zm,M,N);
    C = A0;
    
%     C(zout<A0) = zout(zout<A0);
%     C(~mask_buff) = A0(~mask_buff);
    C(mask) = zout(mask);
    
    A0 = C;
    
    

    
end
% figure;
% surf(X,Y,C)
geotiffwrite(top,C,R,'CoordRefSysCode',26912)
end
 
function [a,w,x_fit,y_fit,z_fit] = fit_tps(x,y,z,npts,lambda)
    %% Fit TPS to selection of mask ring points
	p0 = length(x);
    intp = [npts:npts:length(x)];
    x = x(intp);
    y = y(intp);
    z = z(intp);
	
	% Compute the distances between bpoints
	p = length(x);
	r = zeros(p,p);
	for i = 1:p
		for j = 1:p
            r(i,j) = sqrt((x(i)-x(j))^2+(y(i)-y(j))^2);
        end
	end
	
	% Prepare matrices to solve for w and a
    try
        P = [ones(p,1),x,y];
    catch
        x = x';
        y = y';
        P = [ones(p,1),x,y];
    end
	O = zeros(3);
	K = (r.^2).*log(r);
	iK = isnan(K);
	K(iK) = 0;
	sumr = sum(sum(r));
	alpha = sumr/p^2;
	I = eye(size(K));
	K = I.*lambda*alpha^2+K;
	
	% regularize (Code is present but not active)
% 	lambda = 0.1;
	I = eye(size(K));
	K = I.*lambda+K;
	
	% Solve for w and a
	MAT = [K,P;P',O];
    try
        b = [z;[0;0;0]];
    catch
        z = z';
        b = [z;[0;0;0]];
    end
    R = MAT\b;
	
	w = R(1:p);
	a = R(p+1:end);
	
	x_fit = x;
	y_fit = y;
    z_fit = z;
end

function z = calc_tps(x,y,a,w,X,Y)
    %% Apply TPS defined by w to the mask pixels
	d0 = zeros(length(X),1);
	for i = 1:length(x)
		for j = 1:length(X)
			d0(j,1) = sqrt((X(j)-x(i))^2+(Y(j)-y(i))^2);
		end
		
        rside = sum((d0.^2).*log(d0).*w);
		lside = a(1)+a(2)*x(i)+a(3)*y(i);
		
		z(i) = rside+lside;
		
	end
end

function mask = create_shp_mask(shapefile,feat_num,geotiffinfo)
    %% Create binary mask from input polygons
	% Get x-y locations of pixels
	[x,y] = pixcenters(geotiffinfo);
	
	% Convert x-y arrays to grid
	[X,Y] = meshgrid(x,y);
	
	% Select single polygon and remove training NaN
	rx = shapefile(feat_num).X(1:end-1);
	ry = shapefile(feat_num).Y(1:end-1);
	
	mask = inpolygon(X,Y,rx,ry);
end
